

Online Exam Enrollment



Screenshots

Login Page

<img width="385" height="293" alt="Screenshot 2025-09-24 205652" src="https://github.com/user-attachments/assets/f6f8b6c9-8176-40f7-a957-774743801edd" />

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Dashboard

<img width="488" height="387" alt="image" src="https://github.com/user-attachments/assets/20b4bf62-2389-422d-bc33-332586ab6aa6" />


<img width="496" height="288" alt="image" src="https://github.com/user-attachments/assets/cf1abbd9-221f-499c-92e9-1b01b261dea8" />

<img width="488" height="297" alt="image" src="https://github.com/user-attachments/assets/e083180e-4d33-4655-9d36-23dc164e3be7" />






---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





UML Diagram

Use Case Diagram


<img width="413" height="553" alt="usecase" src="https://github.com/user-attachments/assets/b01ef5ac-8beb-4842-abbb-9690cdea4fea" />


